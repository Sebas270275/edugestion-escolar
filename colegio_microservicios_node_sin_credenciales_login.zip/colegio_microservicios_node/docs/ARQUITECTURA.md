# Arquitectura del proyecto

## Objetivo

Crear una plataforma escolar funcional basada en microservicios y APIs, sin usar PHP.

## Componentes

### 1. API Gateway

Archivo principal: `gateway/server.js`

Función:

- Sirve el frontend.
- Recibe las peticiones `/api/...`.
- Redirige cada petición al microservicio correcto.

### 2. Auth Service

Archivo principal: `services/auth-service/server.js`

Función:

- Login de usuarios.
- Registro básico de estudiantes.
- Generación de token JWT.
- Validación de usuario actual.

### 3. School Service

Archivo principal: `services/school-service/server.js`

Función:

- Datos públicos de la página principal.
- Cursos públicos.
- Comunicados públicos.
- Dashboard de estudiante y docente.

### 4. Admin Service

Archivo principal: `services/admin-service/server.js`

Función:

- Dashboard administrativo.
- Gestión de estudiantes.
- Gestión de docentes.
- Gestión de cursos.
- Gestión de comunicados.
- Generación de datos demo.
- Reportes CSV.

### 5. Shared

Archivos:

- `shared/database.js`
- `shared/auth.js`

Función:

- Conexión a MySQL.
- Creación automática de tablas.
- Datos iniciales.
- Funciones JWT.
- Middleware para proteger rutas.

## Flujo del login

1. El usuario entra a `login.html` o `admin-login.html`.
2. El frontend manda correo y contraseña a `/api/auth/login`.
3. El Gateway redirige la petición al Auth Service.
4. Auth Service valida el correo y la contraseña.
5. Si son correctos, genera un token JWT.
6. El frontend guarda el token en `localStorage`.
7. Las rutas privadas envían el token en el encabezado `Authorization`.
8. Los microservicios validan el token antes de entregar información.

## Base de datos

Tablas principales:

- `users`
- `students`
- `teachers`
- `courses`
- `enrollments`
- `announcements`
- `activity_logs`

## Seguridad aplicada

- Contraseñas encriptadas con bcryptjs.
- Tokens JWT para sesiones.
- Middleware `verifyToken` para rutas privadas.
- Middleware `requireAdmin` para rutas exclusivas del administrador.
- Separación de responsabilidades por microservicio.
