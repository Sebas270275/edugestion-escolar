# EduGestión Escolar Microservicios

Proyecto académico llamado EduGestión Escolar para un sitio web de colegio, 100% funcional, sin PHP, construido con Node.js, Express, MySQL, microservicios, APIs, login por roles y panel de administrador.

## Qué incluye

- Página principal dinámica.
- Login para estudiantes y docentes.
- Login exclusivo para administrador.
- Panel de administrador con estadísticas y gráficas.
- CRUD básico de estudiantes.
- Registro de docentes.
- Registro de cursos.
- Publicación y eliminación de comunicados.
- Generación automática de datos demo.
- Gráficas administrativas: estudiantes por grado, usuarios por rol, matrículas por curso, promedios, comunicados y actividad reciente.
- Descarga de reporte de estudiantes en CSV.
- Base de datos MySQL creada automáticamente.
- APIs protegidas con JWT.
- Arquitectura por microservicios.
- No usa PHP.

## Estructura del proyecto

```txt
colegio_microservicios_node/
│
├── gateway/                      # API Gateway y servidor del frontend
│   └── server.js
│
├── services/
│   ├── auth-service/             # Microservicio de autenticación
│   │   └── server.js
│   ├── school-service/           # Microservicio público/escolar
│   │   └── server.js
│   └── admin-service/            # Microservicio administrativo
│       └── server.js
│
├── shared/                       # Código compartido
│   ├── auth.js                   # JWT y permisos
│   └── database.js               # Conexión, tablas y datos iniciales
│
├── public/                       # Frontend HTML/CSS/JS puro
│   ├── index.html
│   ├── login.html
│   ├── admin-login.html
│   ├── dashboard.html
│   ├── admin.html
│   ├── css/styles.css
│   └── js/
│
├── .env                          # Configuración real del proyecto
├── .env.example                  # Ejemplo de configuración
├── package.json
└── README.md
```

## Requisitos

Antes de ejecutar el proyecto necesitas:

1. Node.js instalado.
2. XAMPP o MySQL instalado.
3. MySQL encendido.
4. Visual Studio Code.

## Instalación paso a paso

### 1. Abrir el proyecto en VS Code

Descomprime el ZIP y abre la carpeta `colegio_microservicios_node` en Visual Studio Code.

### 2. Encender MySQL

Si usas XAMPP, abre XAMPP y presiona `Start` en MySQL.

### 3. Instalar dependencias

Abre la terminal dentro de VS Code y ejecuta:

```bash
npm install
```

### 4. Revisar el archivo .env

El proyecto ya trae un `.env` listo para XAMPP:

```env
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=
DB_NAME=colegio_microservicios
```

Si tu MySQL tiene contraseña, colócala en `DB_PASSWORD`.

### 5. Ejecutar el proyecto

```bash
npm start
```

Esto inicia al mismo tiempo:

- API Gateway: http://localhost:3000
- Auth Service: http://localhost:4001
- School Service: http://localhost:4002
- Admin Service: http://localhost:4003

### 6. Abrir la página

Entra en el navegador a:

```txt
http://localhost:3000
```

## Acceso al sistema

Por seguridad, las credenciales de acceso no se muestran en las pantallas de login.

Los usuarios iniciales siguen existiendo en la base de datos para pruebas internas, pero deben ser entregados únicamente por el encargado del proyecto o modificados directamente desde MySQL/phpMyAdmin.

## Rutas principales

### Frontend

```txt
/                  Página principal
/login.html        Login estudiante/docente
/admin-login.html  Login administrador
/dashboard.html    Panel estudiante/docente
/admin.html        Panel administrador
```

### APIs de autenticación

```txt
POST /api/auth/login
GET  /api/auth/me
POST /api/auth/register-student
```

### APIs públicas

```txt
GET /api/public/overview
GET /api/public/courses
GET /api/public/announcements
```

### APIs del panel escolar

```txt
GET /api/school/my-dashboard
```

### APIs administrativas

```txt
GET    /api/admin/dashboard
GET    /api/admin/charts
GET    /api/admin/students
POST   /api/admin/students
PUT    /api/admin/students/:id
DELETE /api/admin/students/:id
GET    /api/admin/teachers
POST   /api/admin/teachers
GET    /api/admin/courses
POST   /api/admin/courses
GET    /api/admin/announcements
POST   /api/admin/announcements
DELETE /api/admin/announcements/:id
POST   /api/admin/generate-demo-data
GET    /api/admin/reports/students.csv
```

## Explicación corta de la arquitectura

El proyecto trabaja con una arquitectura basada en microservicios:

1. **API Gateway:** recibe las peticiones del navegador y las envía al microservicio correcto.
2. **Auth Service:** se encarga del login, validación de contraseña y generación del token JWT.
3. **School Service:** muestra información pública del colegio y el panel personal de estudiante/docente.
4. **Admin Service:** permite al administrador crear datos, consultar estadísticas y descargar reportes.
5. **MySQL:** almacena usuarios, estudiantes, docentes, cursos, matrículas, comunicados y logs.

## Importante

- El proyecto no usa PHP.
- El frontend está hecho con HTML, CSS y JavaScript puro.
- El backend está hecho con Node.js y Express.
- La base de datos se crea automáticamente al iniciar el proyecto si MySQL está encendido.
- Las contraseñas se guardan encriptadas con bcryptjs.
- Las rutas privadas usan JWT.

## Error común: no conecta con MySQL

Si al ejecutar `npm start` aparece error de conexión:

1. Verifica que MySQL esté encendido.
2. Revisa usuario y contraseña en `.env`.
3. Confirma que el puerto de MySQL sea 3306.
4. Vuelve a ejecutar `npm start`.


## Seguridad de login actualizada

El sistema ahora incluye un control de intentos fallidos en el microservicio de autenticación:

- Cada usuario tiene contador de intentos fallidos.
- Después de 3 contraseñas incorrectas, la cuenta se bloquea durante 1 minuto.
- Mientras la cuenta está bloqueada, el API responde con estado HTTP 423.
- Al iniciar sesión correctamente, el contador se reinicia automáticamente.
- La pantalla de login muestra un contador regresivo del bloqueo temporal.

Si ya tienes una base de datos importada antes de esta versión, ejecuta el archivo:

```sql
database/actualizacion_login_seguro.sql
```

O vuelve a importar `database/colegio_microservicios.sql` si no necesitas conservar datos anteriores.
