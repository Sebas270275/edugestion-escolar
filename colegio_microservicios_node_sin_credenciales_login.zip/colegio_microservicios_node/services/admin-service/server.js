const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '..', '.env') });

const { setupDatabase, getPool, logActivity } = require('../../shared/database');
const { verifyToken, requireAdmin } = require('../../shared/auth');

const app = express();
const PORT = Number(process.env.ADMIN_SERVICE_PORT || 4003);

app.use(cors());
app.use(express.json());

app.get('/health', (req, res) => {
  res.json({ ok: true, service: 'admin-service', message: 'Servicio administrativo activo' });
});

app.use('/api/admin', verifyToken, requireAdmin);

app.get('/api/admin/dashboard', async (req, res) => {
  try {
    const db = await getPool();
    const [[students]] = await db.execute("SELECT COUNT(*) AS total FROM students WHERE estado = 'activo'");
    const [[teachers]] = await db.execute("SELECT COUNT(*) AS total FROM teachers WHERE estado = 'activo'");
    const [[courses]] = await db.execute("SELECT COUNT(*) AS total FROM courses WHERE estado = 'activo'");
    const [[users]] = await db.execute("SELECT COUNT(*) AS total FROM users WHERE estado = 'activo'");
    const [logs] = await db.execute(
      `SELECT l.accion, l.detalle, DATE_FORMAT(l.created_at, '%d/%m/%Y %h:%i %p') AS fecha, COALESCE(u.nombre, 'Sistema') AS usuario
       FROM activity_logs l
       LEFT JOIN users u ON u.id = l.user_id
       ORDER BY l.created_at DESC
       LIMIT 8`
    );

    return res.json({
      ok: true,
      stats: {
        estudiantes: students.total,
        docentes: teachers.total,
        cursos: courses.total,
        usuarios: users.total
      },
      logs
    });
  } catch (error) {
    console.error('Error admin dashboard:', error);
    return res.status(500).json({ ok: false, message: 'Error cargando dashboard admin.' });
  }
});

app.get('/api/admin/charts', async (req, res) => {
  try {
    const db = await getPool();

    const [studentsByGrade] = await db.execute(
      `SELECT grado AS label, COUNT(*) AS total
       FROM students
       WHERE estado = 'activo'
       GROUP BY grado
       ORDER BY grado`
    );

    const [usersByRole] = await db.execute(
      `SELECT role AS label, COUNT(*) AS total
       FROM users
       WHERE estado = 'activo'
       GROUP BY role
       ORDER BY FIELD(role, 'admin', 'docente', 'estudiante')`
    );

    const [enrollmentsByCourse] = await db.execute(
      `SELECT c.nombre AS label, COUNT(e.id) AS total
       FROM courses c
       LEFT JOIN enrollments e ON e.course_id = c.id AND e.estado = 'activo'
       WHERE c.estado = 'activo'
       GROUP BY c.id, c.nombre
       ORDER BY total DESC, c.nombre
       LIMIT 8`
    );

    const [averagesByCourse] = await db.execute(
      `SELECT c.nombre AS label, ROUND(AVG(e.nota_actual), 2) AS total
       FROM courses c
       INNER JOIN enrollments e ON e.course_id = c.id AND e.estado = 'activo'
       WHERE c.estado = 'activo'
       GROUP BY c.id, c.nombre
       ORDER BY c.nombre
       LIMIT 8`
    );

    const [announcementsByAudience] = await db.execute(
      `SELECT audiencia AS label, COUNT(*) AS total
       FROM announcements
       GROUP BY audiencia
       ORDER BY audiencia`
    );

    const [activityByDay] = await db.execute(
      `SELECT DATE_FORMAT(created_at, '%d/%m') AS label, COUNT(*) AS total
       FROM activity_logs
       WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
       GROUP BY DATE(created_at), DATE_FORMAT(created_at, '%d/%m')
       ORDER BY DATE(created_at)`
    );

    return res.json({
      ok: true,
      charts: {
        studentsByGrade,
        usersByRole,
        enrollmentsByCourse,
        averagesByCourse,
        announcementsByAudience,
        activityByDay
      }
    });
  } catch (error) {
    console.error('Error admin charts:', error);
    return res.status(500).json({ ok: false, message: 'Error cargando gráficas del administrador.' });
  }
});

app.get('/api/admin/students', async (req, res) => {
  try {
    const db = await getPool();
    const [rows] = await db.execute(
      `SELECT s.id, s.codigo, s.documento, s.grado, s.acudiente, s.telefono_acudiente, s.direccion,
              s.estado, u.nombre, u.email
       FROM students s
       LEFT JOIN users u ON u.id = s.user_id
       ORDER BY s.id DESC`
    );
    return res.json({ ok: true, students: rows });
  } catch (error) {
    console.error('Error list students:', error);
    return res.status(500).json({ ok: false, message: 'Error listando estudiantes.' });
  }
});

app.post('/api/admin/students', async (req, res) => {
  try {
    const { nombre, email, password, documento, grado, acudiente, telefono_acudiente, direccion } = req.body;
    if (!nombre || !email || !password || !documento || !grado || !acudiente) {
      return res.status(400).json({ ok: false, message: 'Completa nombre, correo, contraseña, documento, grado y acudiente.' });
    }

    const db = await getPool();
    const passwordHash = await bcrypt.hash(password, 10);
    const codigo = `EST-${Date.now().toString().slice(-6)}`;

    const [userResult] = await db.execute(
      'INSERT INTO users (nombre, email, password_hash, role) VALUES (?, ?, ?, ?)',
      [nombre, email.trim().toLowerCase(), passwordHash, 'estudiante']
    );

    await db.execute(
      `INSERT INTO students (user_id, codigo, documento, grado, acudiente, telefono_acudiente, direccion)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [userResult.insertId, codigo, documento, grado, acudiente, telefono_acudiente || '', direccion || '']
    );

    await logActivity(req.user.id, 'CREÓ ESTUDIANTE', `Se creó el estudiante ${nombre} con código ${codigo}.`);
    return res.status(201).json({ ok: true, message: 'Estudiante creado correctamente.', codigo });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ ok: false, message: 'Correo, documento o código duplicado.' });
    }
    console.error('Error create student:', error);
    return res.status(500).json({ ok: false, message: 'Error creando estudiante.' });
  }
});

app.put('/api/admin/students/:id', async (req, res) => {
  try {
    const { nombre, grado, acudiente, telefono_acudiente, direccion, estado } = req.body;
    const db = await getPool();
    const [studentRows] = await db.execute('SELECT user_id FROM students WHERE id = ? LIMIT 1', [req.params.id]);
    if (!studentRows[0]) return res.status(404).json({ ok: false, message: 'Estudiante no encontrado.' });

    await db.execute(
      `UPDATE students SET grado = ?, acudiente = ?, telefono_acudiente = ?, direccion = ?, estado = ? WHERE id = ?`,
      [grado || 'Sin grado', acudiente || 'Sin acudiente', telefono_acudiente || '', direccion || '', estado || 'activo', req.params.id]
    );

    if (nombre) {
      await db.execute('UPDATE users SET nombre = ? WHERE id = ?', [nombre, studentRows[0].user_id]);
    }

    await logActivity(req.user.id, 'ACTUALIZÓ ESTUDIANTE', `Se actualizó el estudiante ID ${req.params.id}.`);
    return res.json({ ok: true, message: 'Estudiante actualizado.' });
  } catch (error) {
    console.error('Error update student:', error);
    return res.status(500).json({ ok: false, message: 'Error actualizando estudiante.' });
  }
});

app.delete('/api/admin/students/:id', async (req, res) => {
  try {
    const db = await getPool();
    const [studentRows] = await db.execute('SELECT user_id FROM students WHERE id = ? LIMIT 1', [req.params.id]);
    if (!studentRows[0]) return res.status(404).json({ ok: false, message: 'Estudiante no encontrado.' });

    await db.execute("UPDATE students SET estado = 'inactivo' WHERE id = ?", [req.params.id]);
    await db.execute("UPDATE users SET estado = 'inactivo' WHERE id = ?", [studentRows[0].user_id]);

    await logActivity(req.user.id, 'DESACTIVÓ ESTUDIANTE', `Se desactivó el estudiante ID ${req.params.id}.`);
    return res.json({ ok: true, message: 'Estudiante desactivado.' });
  } catch (error) {
    console.error('Error delete student:', error);
    return res.status(500).json({ ok: false, message: 'Error desactivando estudiante.' });
  }
});

app.get('/api/admin/teachers', async (req, res) => {
  try {
    const db = await getPool();
    const [rows] = await db.execute(
      `SELECT t.id, t.especialidad, t.telefono, t.estado, u.nombre, u.email
       FROM teachers t
       LEFT JOIN users u ON u.id = t.user_id
       ORDER BY t.id DESC`
    );
    return res.json({ ok: true, teachers: rows });
  } catch (error) {
    console.error('Error list teachers:', error);
    return res.status(500).json({ ok: false, message: 'Error listando docentes.' });
  }
});

app.post('/api/admin/teachers', async (req, res) => {
  try {
    const { nombre, email, password, especialidad, telefono } = req.body;
    if (!nombre || !email || !password || !especialidad) {
      return res.status(400).json({ ok: false, message: 'Completa nombre, correo, contraseña y especialidad.' });
    }

    const db = await getPool();
    const passwordHash = await bcrypt.hash(password, 10);
    const [userResult] = await db.execute(
      'INSERT INTO users (nombre, email, password_hash, role) VALUES (?, ?, ?, ?)',
      [nombre, email.trim().toLowerCase(), passwordHash, 'docente']
    );
    await db.execute('INSERT INTO teachers (user_id, especialidad, telefono) VALUES (?, ?, ?)', [userResult.insertId, especialidad, telefono || '']);

    await logActivity(req.user.id, 'CREÓ DOCENTE', `Se creó el docente ${nombre}.`);
    return res.status(201).json({ ok: true, message: 'Docente creado correctamente.' });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ ok: false, message: 'Ese correo ya está registrado.' });
    }
    console.error('Error create teacher:', error);
    return res.status(500).json({ ok: false, message: 'Error creando docente.' });
  }
});

app.get('/api/admin/courses', async (req, res) => {
  try {
    const db = await getPool();
    const [rows] = await db.execute(
      `SELECT c.id, c.nombre, c.grado, c.descripcion, c.estado, c.docente_id, COALESCE(u.nombre, 'Sin docente') AS docente
       FROM courses c
       LEFT JOIN teachers t ON t.id = c.docente_id
       LEFT JOIN users u ON u.id = t.user_id
       ORDER BY c.id DESC`
    );
    return res.json({ ok: true, courses: rows });
  } catch (error) {
    console.error('Error list courses:', error);
    return res.status(500).json({ ok: false, message: 'Error listando cursos.' });
  }
});

app.post('/api/admin/courses', async (req, res) => {
  try {
    const { nombre, grado, descripcion, docente_id } = req.body;
    if (!nombre || !grado) return res.status(400).json({ ok: false, message: 'Nombre y grado son obligatorios.' });

    const db = await getPool();
    await db.execute(
      'INSERT INTO courses (nombre, grado, descripcion, docente_id) VALUES (?, ?, ?, ?)',
      [nombre, grado, descripcion || '', docente_id || null]
    );

    await logActivity(req.user.id, 'CREÓ CURSO', `Se creó el curso ${nombre} para el grado ${grado}.`);
    return res.status(201).json({ ok: true, message: 'Curso creado correctamente.' });
  } catch (error) {
    console.error('Error create course:', error);
    return res.status(500).json({ ok: false, message: 'Error creando curso.' });
  }
});

app.get('/api/admin/announcements', async (req, res) => {
  try {
    const db = await getPool();
    const [rows] = await db.execute(
      `SELECT id, titulo, contenido, audiencia, DATE_FORMAT(created_at, '%d/%m/%Y %h:%i %p') AS fecha
       FROM announcements
       ORDER BY created_at DESC`
    );
    return res.json({ ok: true, announcements: rows });
  } catch (error) {
    console.error('Error list announcements:', error);
    return res.status(500).json({ ok: false, message: 'Error listando comunicados.' });
  }
});

app.post('/api/admin/announcements', async (req, res) => {
  try {
    const { titulo, contenido, audiencia } = req.body;
    if (!titulo || !contenido) return res.status(400).json({ ok: false, message: 'Título y contenido son obligatorios.' });

    const db = await getPool();
    await db.execute(
      'INSERT INTO announcements (titulo, contenido, audiencia, created_by) VALUES (?, ?, ?, ?)',
      [titulo, contenido, audiencia || 'todos', req.user.id]
    );

    await logActivity(req.user.id, 'CREÓ COMUNICADO', `Se publicó el comunicado: ${titulo}.`);
    return res.status(201).json({ ok: true, message: 'Comunicado publicado.' });
  } catch (error) {
    console.error('Error create announcement:', error);
    return res.status(500).json({ ok: false, message: 'Error creando comunicado.' });
  }
});

app.delete('/api/admin/announcements/:id', async (req, res) => {
  try {
    const db = await getPool();
    await db.execute('DELETE FROM announcements WHERE id = ?', [req.params.id]);
    await logActivity(req.user.id, 'ELIMINÓ COMUNICADO', `Se eliminó el comunicado ID ${req.params.id}.`);
    return res.json({ ok: true, message: 'Comunicado eliminado.' });
  } catch (error) {
    console.error('Error delete announcement:', error);
    return res.status(500).json({ ok: false, message: 'Error eliminando comunicado.' });
  }
});

app.post('/api/admin/generate-demo-data', async (req, res) => {
  try {
    const db = await getPool();
    const grado = req.body.grado || '10A';
    const total = Math.min(Number(req.body.total || 8), 50);
    const passwordHash = await bcrypt.hash('Estudiante123*', 10);
    const created = [];

    for (let i = 1; i <= total; i++) {
      const stamp = `${Date.now()}${i}`.slice(-8);
      const nombre = `Estudiante Demo ${stamp}`;
      const email = `demo${stamp}@colegio.edu.co`;
      const codigo = `EST-${stamp}`;
      const documento = `10${stamp}`;

      const [userResult] = await db.execute(
        'INSERT INTO users (nombre, email, password_hash, role) VALUES (?, ?, ?, ?)',
        [nombre, email, passwordHash, 'estudiante']
      );

      const [studentResult] = await db.execute(
        `INSERT INTO students (user_id, codigo, documento, grado, acudiente, telefono_acudiente, direccion)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [userResult.insertId, codigo, documento, grado, `Acudiente ${stamp}`, '3000000000', 'Dirección demo']
      );

      const [courses] = await db.execute('SELECT id FROM courses WHERE grado = ? LIMIT 3', [grado]);
      for (const course of courses) {
        await db.execute(
          'INSERT IGNORE INTO enrollments (student_id, course_id, nota_actual) VALUES (?, ?, ?)',
          [studentResult.insertId, course.id, Number((3 + Math.random() * 2).toFixed(2))]
        );
      }
      created.push({ nombre, email, codigo });
    }

    await logActivity(req.user.id, 'GENERÓ DATA DEMO', `Se generaron ${created.length} estudiantes demo para el grado ${grado}.`);
    return res.status(201).json({ ok: true, message: `Se generaron ${created.length} estudiantes demo.`, created });
  } catch (error) {
    console.error('Error generate data:', error);
    return res.status(500).json({ ok: false, message: 'Error generando data demo.' });
  }
});

app.get('/api/admin/reports/students.csv', async (req, res) => {
  try {
    const db = await getPool();
    const [rows] = await db.execute(
      `SELECT s.codigo, u.nombre, u.email, s.documento, s.grado, s.acudiente, s.telefono_acudiente, s.estado
       FROM students s
       LEFT JOIN users u ON u.id = s.user_id
       ORDER BY s.grado, u.nombre`
    );

    const headers = ['codigo', 'nombre', 'email', 'documento', 'grado', 'acudiente', 'telefono_acudiente', 'estado'];
    const escapeCsv = (value) => `"${String(value ?? '').replace(/"/g, '""')}"`;
    const csv = [headers.join(','), ...rows.map(row => headers.map(header => escapeCsv(row[header])).join(','))].join('\n');

    await logActivity(req.user.id, 'DESCARGÓ REPORTE', 'Descargó reporte CSV de estudiantes.');

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="reporte_estudiantes.csv"');
    return res.send('\ufeff' + csv);
  } catch (error) {
    console.error('Error report students:', error);
    return res.status(500).json({ ok: false, message: 'Error generando reporte.' });
  }
});

setupDatabase()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Admin service listo en http://localhost:${PORT}`);
    });
  })
  .catch((error) => {
    console.error('No se pudo iniciar Admin Service. Revisa MySQL y .env:', error.message);
    process.exit(1);
  });
