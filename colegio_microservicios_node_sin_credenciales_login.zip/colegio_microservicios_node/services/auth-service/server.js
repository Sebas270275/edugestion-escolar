const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '..', '.env') });

const { setupDatabase, getPool, logActivity } = require('../../shared/database');
const { signToken, verifyToken } = require('../../shared/auth');

const app = express();
const PORT = Number(process.env.AUTH_SERVICE_PORT || 4001);

app.use(cors());
app.use(express.json());

function toMysqlDateTime(date) {
  const pad = (value) => String(value).padStart(2, '0');
  const year = date.getFullYear();
  const month = pad(date.getMonth() + 1);
  const day = pad(date.getDate());
  const hours = pad(date.getHours());
  const minutes = pad(date.getMinutes());
  const seconds = pad(date.getSeconds());
  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

app.get('/health', (req, res) => {
  res.json({ ok: true, service: 'auth-service', message: 'Servicio de autenticación activo' });
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const normalizedEmail = String(email || '').trim().toLowerCase();

    if (!normalizedEmail || !password) {
      return res.status(400).json({ ok: false, message: 'Correo y contraseña son obligatorios.' });
    }

    const db = await getPool();
    const [rows] = await db.execute(
      `SELECT id, nombre, email, password_hash, role, estado, failed_login_attempts, locked_until
       FROM users
       WHERE email = ?
       LIMIT 1`,
      [normalizedEmail]
    );

    const user = rows[0];

    if (!user || user.estado !== 'activo') {
      return res.status(401).json({ ok: false, message: 'Usuario no encontrado o inactivo.' });
    }

    const now = new Date();
    const lockedUntil = user.locked_until ? new Date(user.locked_until) : null;

    if (lockedUntil && lockedUntil.getTime() > now.getTime()) {
      const lockSeconds = Math.ceil((lockedUntil.getTime() - now.getTime()) / 1000);
      return res.status(423).json({
        ok: false,
        locked: true,
        lockSeconds,
        message: `Cuenta bloqueada temporalmente. Intenta de nuevo en ${lockSeconds} segundos.`
      });
    }

    if (lockedUntil && lockedUntil.getTime() <= now.getTime()) {
      await db.execute(
        'UPDATE users SET failed_login_attempts = 0, locked_until = NULL WHERE id = ?',
        [user.id]
      );
      user.failed_login_attempts = 0;
      user.locked_until = null;
    }

    const isValid = await bcrypt.compare(password, user.password_hash);
    if (!isValid) {
      const failedAttempts = Number(user.failed_login_attempts || 0) + 1;

      if (failedAttempts >= 3) {
        const nextUnlock = new Date(Date.now() + 60 * 1000);
        const mysqlUnlock = toMysqlDateTime(nextUnlock);

        await db.execute(
          'UPDATE users SET failed_login_attempts = ?, locked_until = ? WHERE id = ?',
          [failedAttempts, mysqlUnlock, user.id]
        );

        await logActivity(
          user.id,
          'BLOQUEO TEMPORAL DE CUENTA',
          `La cuenta ${user.email} fue bloqueada durante 1 minuto por 3 intentos fallidos de inicio de sesión.`
        );

        return res.status(423).json({
          ok: false,
          locked: true,
          lockSeconds: 60,
          message: 'Cuenta bloqueada por 1 minuto debido a 3 intentos fallidos.'
        });
      }

      await db.execute(
        'UPDATE users SET failed_login_attempts = ?, locked_until = NULL WHERE id = ?',
        [failedAttempts, user.id]
      );

      return res.status(401).json({
        ok: false,
        attemptsRemaining: 3 - failedAttempts,
        message: `Contraseña incorrecta. Te quedan ${3 - failedAttempts} intento(s) antes del bloqueo temporal.`
      });
    }

    await db.execute(
      'UPDATE users SET failed_login_attempts = 0, locked_until = NULL WHERE id = ?',
      [user.id]
    );

    const publicUser = {
      id: user.id,
      nombre: user.nombre,
      email: user.email,
      role: user.role
    };

    await logActivity(user.id, 'INICIO DE SESIÓN', `El usuario ${user.email} inició sesión.`);

    return res.json({
      ok: true,
      message: 'Inicio de sesión exitoso.',
      token: signToken(publicUser),
      user: publicUser
    });
  } catch (error) {
    console.error('Error login:', error);
    return res.status(500).json({ ok: false, message: 'Error interno en autenticación.' });
  }
});

app.post('/api/auth/register-student', async (req, res) => {
  try {
    const { nombre, email, password, documento, grado, acudiente, telefono_acudiente, direccion } = req.body;

    if (!nombre || !email || !password || !documento || !grado || !acudiente) {
      return res.status(400).json({ ok: false, message: 'Faltan datos obligatorios para registrar estudiante.' });
    }

    const db = await getPool();
    const passwordHash = await bcrypt.hash(password, 10);
    const codigo = `EST-${Date.now().toString().slice(-6)}`;

    const [userResult] = await db.execute(
      'INSERT INTO users (nombre, email, password_hash, role) VALUES (?, ?, ?, ?)',
      [nombre, email.trim().toLowerCase(), passwordHash, 'estudiante']
    );

    await db.execute(
      `INSERT INTO students (user_id, codigo, documento, grado, acudiente, telefono_acudiente, direccion)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [userResult.insertId, codigo, documento, grado, acudiente, telefono_acudiente || '', direccion || '']
    );

    await logActivity(userResult.insertId, 'REGISTRO DE ESTUDIANTE', `Se registró el estudiante ${nombre}.`);

    return res.status(201).json({ ok: true, message: 'Estudiante registrado correctamente.', codigo });
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      return res.status(409).json({ ok: false, message: 'El correo o código ya está registrado.' });
    }
    console.error('Error register-student:', error);
    return res.status(500).json({ ok: false, message: 'Error interno al registrar estudiante.' });
  }
});

app.get('/api/auth/me', verifyToken, async (req, res) => {
  try {
    const db = await getPool();
    const [rows] = await db.execute('SELECT id, nombre, email, role, estado FROM users WHERE id = ? LIMIT 1', [req.user.id]);

    if (!rows[0]) {
      return res.status(404).json({ ok: false, message: 'Usuario no encontrado.' });
    }

    return res.json({ ok: true, user: rows[0] });
  } catch (error) {
    console.error('Error me:', error);
    return res.status(500).json({ ok: false, message: 'Error interno al validar usuario.' });
  }
});

setupDatabase()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Auth service listo en http://localhost:${PORT}`);
    });
  })
  .catch((error) => {
    console.error('No se pudo iniciar Auth Service. Revisa MySQL y .env:', error.message);
    process.exit(1);
  });
