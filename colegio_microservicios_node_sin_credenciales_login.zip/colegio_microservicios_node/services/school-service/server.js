const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '..', '.env') });

const { setupDatabase, getPool } = require('../../shared/database');
const { verifyToken, requireRoles } = require('../../shared/auth');

const app = express();
const PORT = Number(process.env.SCHOOL_SERVICE_PORT || 4002);

app.use(cors());
app.use(express.json());

app.get('/health', (req, res) => {
  res.json({ ok: true, service: 'school-service', message: 'Servicio escolar activo' });
});

app.get('/api/public/overview', async (req, res) => {
  try {
    const db = await getPool();
    const [[students]] = await db.execute("SELECT COUNT(*) AS total FROM students WHERE estado = 'activo'");
    const [[teachers]] = await db.execute("SELECT COUNT(*) AS total FROM teachers WHERE estado = 'activo'");
    const [[courses]] = await db.execute("SELECT COUNT(*) AS total FROM courses WHERE estado = 'activo'");
    const [announcements] = await db.execute(
      `SELECT id, titulo, contenido, audiencia, DATE_FORMAT(created_at, '%d/%m/%Y') AS fecha
       FROM announcements
       ORDER BY created_at DESC
       LIMIT 4`
    );

    return res.json({
      ok: true,
      stats: {
        estudiantes: students.total,
        docentes: teachers.total,
        cursos: courses.total,
        comunicados: announcements.length
      },
      announcements
    });
  } catch (error) {
    console.error('Error overview:', error);
    return res.status(500).json({ ok: false, message: 'Error cargando la página principal.' });
  }
});

app.get('/api/public/courses', async (req, res) => {
  try {
    const db = await getPool();
    const [rows] = await db.execute(
      `SELECT c.id, c.nombre, c.grado, c.descripcion, COALESCE(u.nombre, 'Sin docente asignado') AS docente
       FROM courses c
       LEFT JOIN teachers t ON t.id = c.docente_id
       LEFT JOIN users u ON u.id = t.user_id
       WHERE c.estado = 'activo'
       ORDER BY c.grado, c.nombre`
    );
    return res.json({ ok: true, courses: rows });
  } catch (error) {
    console.error('Error public courses:', error);
    return res.status(500).json({ ok: false, message: 'Error cargando cursos.' });
  }
});

app.get('/api/public/announcements', async (req, res) => {
  try {
    const db = await getPool();
    const [rows] = await db.execute(
      `SELECT id, titulo, contenido, audiencia, DATE_FORMAT(created_at, '%d/%m/%Y %h:%i %p') AS fecha
       FROM announcements
       ORDER BY created_at DESC`
    );
    return res.json({ ok: true, announcements: rows });
  } catch (error) {
    console.error('Error announcements:', error);
    return res.status(500).json({ ok: false, message: 'Error cargando comunicados.' });
  }
});

app.get('/api/school/my-dashboard', verifyToken, requireRoles('estudiante', 'docente', 'admin'), async (req, res) => {
  try {
    const db = await getPool();

    if (req.user.role === 'estudiante') {
      const [profileRows] = await db.execute(
        `SELECT s.id, s.codigo, s.documento, s.grado, s.acudiente, s.telefono_acudiente, u.nombre, u.email
         FROM students s
         INNER JOIN users u ON u.id = s.user_id
         WHERE s.user_id = ? LIMIT 1`,
        [req.user.id]
      );

      const profile = profileRows[0];
      if (!profile) return res.status(404).json({ ok: false, message: 'Perfil de estudiante no encontrado.' });

      const [courses] = await db.execute(
        `SELECT c.nombre, c.grado, c.descripcion, e.nota_actual, COALESCE(tu.nombre, 'Sin docente') AS docente
         FROM enrollments e
         INNER JOIN courses c ON c.id = e.course_id
         LEFT JOIN teachers t ON t.id = c.docente_id
         LEFT JOIN users tu ON tu.id = t.user_id
         WHERE e.student_id = ? AND e.estado = 'activo'`,
        [profile.id]
      );

      return res.json({ ok: true, role: 'estudiante', profile, courses });
    }

    if (req.user.role === 'docente') {
      const [profileRows] = await db.execute(
        `SELECT t.id, t.especialidad, t.telefono, u.nombre, u.email
         FROM teachers t
         INNER JOIN users u ON u.id = t.user_id
         WHERE t.user_id = ? LIMIT 1`,
        [req.user.id]
      );

      const profile = profileRows[0];
      if (!profile) return res.status(404).json({ ok: false, message: 'Perfil de docente no encontrado.' });

      const [courses] = await db.execute(
        `SELECT c.id, c.nombre, c.grado, c.descripcion, COUNT(e.id) AS matriculados
         FROM courses c
         LEFT JOIN enrollments e ON e.course_id = c.id
         WHERE c.docente_id = ?
         GROUP BY c.id
         ORDER BY c.nombre`,
        [profile.id]
      );

      return res.json({ ok: true, role: 'docente', profile, courses });
    }

    return res.json({ ok: true, role: 'admin', message: 'Administrador conectado. Entra al panel administrativo.' });
  } catch (error) {
    console.error('Error my-dashboard:', error);
    return res.status(500).json({ ok: false, message: 'Error cargando dashboard personal.' });
  }
});

setupDatabase()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`School service listo en http://localhost:${PORT}`);
    });
  })
  .catch((error) => {
    console.error('No se pudo iniciar School Service. Revisa MySQL y .env:', error.message);
    process.exit(1);
  });
