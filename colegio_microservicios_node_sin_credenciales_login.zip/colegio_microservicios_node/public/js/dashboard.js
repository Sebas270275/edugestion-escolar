const token = localStorage.getItem('colegio_token');
const user = JSON.parse(localStorage.getItem('colegio_user') || 'null');

if (!token || !user) {
  window.location.href = 'login.html';
}

document.getElementById('logoutBtn').addEventListener('click', () => {
  localStorage.removeItem('colegio_token');
  localStorage.removeItem('colegio_user');
  window.location.href = 'login.html';
});

async function authFetch(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      ...(options.headers || {})
    }
  });

  if (response.status === 401 || response.status === 403) {
    localStorage.clear();
    window.location.href = 'login.html';
    return null;
  }

  return response.json();
}

function card(title, value, text) {
  return `
    <article class="card">
      <p class="muted">${title}</p>
      <h3>${value}</h3>
      <p>${text}</p>
    </article>
  `;
}

async function loadDashboard() {
  const data = await authFetch('/api/school/my-dashboard');
  if (!data || !data.ok) return;

  const profile = data.profile || {};
  document.getElementById('welcomeTitle').textContent = `Hola, ${profile.nombre || user.nombre}`;

  if (data.role === 'estudiante') {
    document.getElementById('profileCards').innerHTML = [
      card('Código', profile.codigo, 'Identificación académica'),
      card('Grado', profile.grado, 'Grupo actual'),
      card('Acudiente', profile.acudiente, profile.telefono_acudiente || 'Sin teléfono')
    ].join('');

    document.getElementById('coursesHead').innerHTML = '<tr><th>Curso</th><th>Grado</th><th>Docente</th><th>Nota actual</th></tr>';
    document.getElementById('coursesBody').innerHTML = (data.courses || []).map(course => `
      <tr>
        <td>${course.nombre}</td>
        <td>${course.grado}</td>
        <td>${course.docente}</td>
        <td>${course.nota_actual}</td>
      </tr>
    `).join('');
  }

  if (data.role === 'docente') {
    document.getElementById('profileCards').innerHTML = [
      card('Especialidad', profile.especialidad, 'Área de enseñanza'),
      card('Correo', profile.email, 'Contacto institucional'),
      card('Teléfono', profile.telefono || 'Sin teléfono', 'Información de contacto')
    ].join('');

    document.getElementById('coursesHead').innerHTML = '<tr><th>Curso</th><th>Grado</th><th>Descripción</th><th>Matriculados</th></tr>';
    document.getElementById('coursesBody').innerHTML = (data.courses || []).map(course => `
      <tr>
        <td>${course.nombre}</td>
        <td>${course.grado}</td>
        <td>${course.descripcion || 'Sin descripción'}</td>
        <td>${course.matriculados}</td>
      </tr>
    `).join('');
  }
}

loadDashboard();
