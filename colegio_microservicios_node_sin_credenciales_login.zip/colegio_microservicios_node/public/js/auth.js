const form = document.getElementById('loginForm');
const message = document.getElementById('message');
const submitButton = form.querySelector('button[type="submit"]');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
let lockTimer = null;

function showMessage(text, isError = false) {
  message.textContent = text;
  message.classList.remove('hidden');
  message.classList.toggle('error', isError);
}

function setFormDisabled(disabled) {
  submitButton.disabled = disabled;
  emailInput.disabled = disabled;
  passwordInput.disabled = disabled;
  form.classList.toggle('is-locked', disabled);
}

function formatTime(seconds) {
  const safeSeconds = Math.max(0, Number(seconds || 0));
  const minutes = String(Math.floor(safeSeconds / 60)).padStart(2, '0');
  const remainingSeconds = String(safeSeconds % 60).padStart(2, '0');
  return `${minutes}:${remainingSeconds}`;
}

function startLockCountdown(seconds = 60) {
  if (lockTimer) clearInterval(lockTimer);

  let remaining = Number(seconds || 60);
  setFormDisabled(true);
  showMessage(`Acceso bloqueado temporalmente. Intenta nuevamente en ${formatTime(remaining)}.`, true);

  lockTimer = setInterval(() => {
    remaining -= 1;

    if (remaining <= 0) {
      clearInterval(lockTimer);
      lockTimer = null;
      setFormDisabled(false);
      passwordInput.value = '';
      showMessage('El bloqueo terminó. Ya puedes intentar iniciar sesión nuevamente.');
      passwordInput.focus();
      return;
    }

    showMessage(`Acceso bloqueado temporalmente. Intenta nuevamente en ${formatTime(remaining)}.`, true);
  }, 1000);
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();

  const email = emailInput.value.trim();
  const password = passwordInput.value;
  const mode = form.dataset.mode;

  try {
    submitButton.disabled = true;
    showMessage('Validando credenciales...');

    const response = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });

    const data = await response.json();

    if (data.locked) {
      startLockCountdown(data.lockSeconds || 60);
      return;
    }

    if (!response.ok || !data.ok) {
      showMessage(data.message || 'No se pudo iniciar sesión.', true);
      submitButton.disabled = false;
      return;
    }

    if (mode === 'admin' && data.user.role !== 'admin') {
      showMessage('Este login es solo para administrador.', true);
      submitButton.disabled = false;
      return;
    }

    localStorage.setItem('colegio_token', data.token);
    localStorage.setItem('colegio_user', JSON.stringify(data.user));

    if (data.user.role === 'admin') {
      window.location.href = 'admin.html';
    } else {
      window.location.href = 'dashboard.html';
    }
  } catch (error) {
    console.error(error);
    showMessage('Error de conexión. Asegúrate de ejecutar npm start.', true);
    submitButton.disabled = false;
  }
});
