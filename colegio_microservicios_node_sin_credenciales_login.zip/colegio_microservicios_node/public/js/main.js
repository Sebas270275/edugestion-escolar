async function getJson(url) {
  const response = await fetch(url);
  return response.json();
}

function renderStats(stats) {
  const values = [
    { number: stats.estudiantes, title: 'Estudiantes', text: 'Registrados en el sistema.' },
    { number: stats.docentes, title: 'Docentes', text: 'Activos en la plataforma.' },
    { number: stats.cursos, title: 'Cursos', text: 'Disponibles por grado.' },
    { number: stats.comunicados, title: 'Comunicados', text: 'Publicados por admin.' }
  ];

  document.getElementById('statsGrid').innerHTML = values.map(item => `
    <article class="card">
      <div class="stat-number">${item.number}</div>
      <h3>${item.title}</h3>
      <p>${item.text}</p>
    </article>
  `).join('');
}

function renderCourses(courses) {
  const container = document.getElementById('coursesGrid');
  if (!courses.length) {
    container.innerHTML = '<article class="card"><h3>No hay cursos</h3><p>Aún no existen cursos activos.</p></article>';
    return;
  }

  container.innerHTML = courses.map(course => `
    <article class="card">
      <h3>${course.nombre}</h3>
      <p><strong>Grado:</strong> ${course.grado}</p>
      <p>${course.descripcion || 'Curso académico del colegio.'}</p>
      <p class="muted"><strong>Docente:</strong> ${course.docente}</p>
    </article>
  `).join('');
}

function renderAnnouncements(announcements) {
  const container = document.getElementById('announcementsGrid');
  if (!announcements.length) {
    container.innerHTML = '<article class="card"><h3>No hay comunicados</h3><p>El administrador aún no ha publicado noticias.</p></article>';
    return;
  }

  container.innerHTML = announcements.map(item => `
    <article class="card">
      <p class="muted">${item.fecha} · ${item.audiencia}</p>
      <h3>${item.titulo}</h3>
      <p>${item.contenido}</p>
    </article>
  `).join('');
}

async function initHome() {
  try {
    const overview = await getJson('/api/public/overview');
    const courses = await getJson('/api/public/courses');
    renderStats(overview.stats || {});
    renderCourses(courses.courses || []);
    renderAnnouncements(overview.announcements || []);
  } catch (error) {
    console.error(error);
    document.getElementById('announcementsGrid').innerHTML = `
      <article class="card">
        <h3>No se pudo conectar</h3>
        <p>Verifica que el proyecto esté corriendo con npm start.</p>
      </article>`;
  }
}

initHome();
