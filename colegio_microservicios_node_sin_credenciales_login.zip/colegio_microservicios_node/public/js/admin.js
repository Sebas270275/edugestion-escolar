const token = localStorage.getItem('colegio_token');
const user = JSON.parse(localStorage.getItem('colegio_user') || 'null');

if (!token || !user || user.role !== 'admin') {
  window.location.href = 'admin-login.html';
}

const logoutBtn = document.getElementById('logoutBtn');
logoutBtn.addEventListener('click', () => {
  localStorage.removeItem('colegio_token');
  localStorage.removeItem('colegio_user');
  window.location.href = 'admin-login.html';
});

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      ...(options.headers || {})
    }
  });

  if (response.status === 401 || response.status === 403) {
    localStorage.clear();
    window.location.href = 'admin-login.html';
    return null;
  }

  const data = await response.json();
  if (!response.ok || data.ok === false) {
    throw new Error(data.message || 'Ocurrió un error en la API');
  }
  return data;
}

function formToJson(form) {
  return Object.fromEntries(new FormData(form).entries());
}

function statCard(number, title, text) {
  return `
    <article class="card">
      <div class="stat-number">${number}</div>
      <h3>${title}</h3>
      <p>${text}</p>
    </article>
  `;
}

function cssVar(name, fallback) {
  const value = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return value || fallback;
}

function setupCanvas(canvas) {
  const dpr = window.devicePixelRatio || 1;
  const rect = canvas.getBoundingClientRect();
  const width = Math.max(rect.width, 320);
  const height = Math.max(rect.height || Number(canvas.getAttribute('height')) || 260, 230);
  canvas.width = width * dpr;
  canvas.height = height * dpr;
  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, width, height);
  return { ctx, width, height };
}

function shortText(text, limit = 16) {
  const value = String(text || 'Sin dato');
  return value.length > limit ? `${value.slice(0, limit - 3)}...` : value;
}

function drawEmpty(ctx, width, height, message) {
  ctx.fillStyle = cssVar('--muted', '#64748b');
  ctx.font = '700 15px Arial';
  ctx.textAlign = 'center';
  ctx.fillText(message, width / 2, height / 2);
}

function drawBarChart(canvasId, rows, options = {}) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;

  const { ctx, width, height } = setupCanvas(canvas);
  const data = (rows || []).map(item => ({
    label: item.label || 'Sin dato',
    total: Number(item.total || 0)
  })).filter(item => !Number.isNaN(item.total));

  if (!data.length) {
    drawEmpty(ctx, width, height, 'Sin datos para mostrar');
    return;
  }

  const primary = cssVar('--primary', '#2563eb');
  const accent = cssVar('--accent', '#f59e0b');
  const border = cssVar('--border', '#e2e8f0');
  const text = cssVar('--secondary', '#0f172a');
  const muted = cssVar('--muted', '#64748b');

  const padding = { top: 26, right: 18, bottom: 54, left: 46 };
  const chartW = width - padding.left - padding.right;
  const chartH = height - padding.top - padding.bottom;
  const maxValue = Math.max(options.maxValue || 0, ...data.map(item => item.total), 1);
  const barGap = 12;
  const barWidth = Math.max(18, (chartW - barGap * (data.length - 1)) / data.length);

  ctx.strokeStyle = border;
  ctx.lineWidth = 1;
  ctx.font = '12px Arial';
  ctx.textAlign = 'right';
  ctx.fillStyle = muted;

  for (let i = 0; i <= 4; i++) {
    const y = padding.top + chartH - (chartH * i / 4);
    const value = Math.round(maxValue * i / 4 * 10) / 10;
    ctx.beginPath();
    ctx.moveTo(padding.left, y);
    ctx.lineTo(width - padding.right, y);
    ctx.stroke();
    ctx.fillText(value, padding.left - 8, y + 4);
  }

  data.forEach((item, index) => {
    const x = padding.left + index * (barWidth + barGap);
    const barH = (item.total / maxValue) * chartH;
    const y = padding.top + chartH - barH;
    const gradient = ctx.createLinearGradient(0, y, 0, padding.top + chartH);
    gradient.addColorStop(0, index % 2 === 0 ? primary : accent);
    gradient.addColorStop(1, 'rgba(37, 99, 235, 0.18)');

    ctx.fillStyle = gradient;
    ctx.beginPath();
    if (ctx.roundRect) {
      ctx.roundRect(x, y, barWidth, barH, 9);
      ctx.fill();
    } else {
      ctx.fillRect(x, y, barWidth, barH);
    }

    ctx.fillStyle = text;
    ctx.font = '800 13px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(String(item.total), x + barWidth / 2, Math.max(y - 8, 16));

    ctx.fillStyle = muted;
    ctx.font = '12px Arial';
    ctx.fillText(shortText(item.label, options.labelLimit || 13), x + barWidth / 2, height - 22);
  });
}

function drawDoughnutChart(canvasId, rows) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;

  const { ctx, width, height } = setupCanvas(canvas);
  const data = (rows || []).map(item => ({
    label: item.label || 'Sin dato',
    total: Number(item.total || 0)
  })).filter(item => item.total > 0);

  if (!data.length) {
    drawEmpty(ctx, width, height, 'Sin datos para mostrar');
    return;
  }

  const palette = [
    cssVar('--primary', '#2563eb'),
    cssVar('--accent', '#f59e0b'),
    cssVar('--success', '#16a34a'),
    cssVar('--danger', '#dc2626'),
    '#7c3aed'
  ];
  const muted = cssVar('--muted', '#64748b');
  const text = cssVar('--secondary', '#0f172a');
  const total = data.reduce((sum, item) => sum + item.total, 0);
  const centerX = width * 0.34;
  const centerY = height * 0.48;
  const radius = Math.min(width, height) * 0.25;
  let start = -Math.PI / 2;

  data.forEach((item, index) => {
    const angle = (item.total / total) * Math.PI * 2;
    ctx.beginPath();
    ctx.moveTo(centerX, centerY);
    ctx.arc(centerX, centerY, radius, start, start + angle);
    ctx.closePath();
    ctx.fillStyle = palette[index % palette.length];
    ctx.fill();
    start += angle;
  });

  ctx.globalCompositeOperation = 'destination-out';
  ctx.beginPath();
  ctx.arc(centerX, centerY, radius * 0.58, 0, Math.PI * 2);
  ctx.fill();
  ctx.globalCompositeOperation = 'source-over';

  ctx.fillStyle = text;
  ctx.font = '800 24px Arial';
  ctx.textAlign = 'center';
  ctx.fillText(total, centerX, centerY + 8);
  ctx.font = '12px Arial';
  ctx.fillStyle = muted;
  ctx.fillText('usuarios', centerX, centerY + 28);

  const legendX = width * 0.62;
  let legendY = Math.max(38, centerY - data.length * 18);
  ctx.textAlign = 'left';

  data.forEach((item, index) => {
    const percent = Math.round((item.total / total) * 100);
    ctx.fillStyle = palette[index % palette.length];
    ctx.beginPath();
    ctx.roundRect ? ctx.roundRect(legendX, legendY - 10, 12, 12, 4) : ctx.fillRect(legendX, legendY - 10, 12, 12);
    ctx.fill();
    ctx.fillStyle = text;
    ctx.font = '700 13px Arial';
    ctx.fillText(`${item.label}: ${item.total}`, legendX + 20, legendY);
    ctx.fillStyle = muted;
    ctx.font = '12px Arial';
    ctx.fillText(`${percent}%`, legendX + 20, legendY + 16);
    legendY += 42;
  });
}

async function loadDashboard() {
  const data = await api('/api/admin/dashboard');
  if (!data) return;

  document.getElementById('adminStats').innerHTML = [
    statCard(data.stats.estudiantes, 'Estudiantes', 'Activos en el sistema'),
    statCard(data.stats.docentes, 'Docentes', 'Activos en la institución'),
    statCard(data.stats.cursos, 'Cursos', 'Oferta académica'),
    statCard(data.stats.usuarios, 'Usuarios', 'Cuentas registradas')
  ].join('');

  document.getElementById('logsList').innerHTML = (data.logs || []).map(log => `
    <div style="padding:12px 0;border-bottom:1px solid var(--border);">
      <strong>${log.accion}</strong>
      <p class="muted">${log.detalle || ''}</p>
      <small>${log.usuario} · ${log.fecha}</small>
    </div>
  `).join('') || '<p class="muted">Sin actividad registrada.</p>';
}

let lastChartsData = null;

async function loadCharts() {
  const data = await api('/api/admin/charts');
  if (!data) return;

  lastChartsData = data.charts;
  drawCharts(lastChartsData);
}

function drawCharts(charts) {
  if (!charts) return;
  drawBarChart('gradeChart', charts.studentsByGrade, { labelLimit: 12 });
  drawDoughnutChart('roleChart', charts.usersByRole);
  drawBarChart('courseChart', charts.enrollmentsByCourse, { labelLimit: 14 });
  drawBarChart('averageChart', charts.averagesByCourse, { maxValue: 5, labelLimit: 14 });
  drawDoughnutChart('announcementChart', charts.announcementsByAudience);
  drawBarChart('activityChart', charts.activityByDay, { labelLimit: 8 });
}

async function loadStudents() {
  const data = await api('/api/admin/students');
  if (!data) return;

  document.getElementById('studentsTable').innerHTML = (data.students || []).map(student => `
    <tr>
      <td>${student.codigo}</td>
      <td>${student.nombre || 'Sin nombre'}</td>
      <td>${student.email || 'Sin correo'}</td>
      <td>${student.grado}</td>
      <td>${student.acudiente}</td>
      <td>${student.estado}</td>
      <td>
        <button class="btn-danger" onclick="deactivateStudent(${student.id})">Desactivar</button>
      </td>
    </tr>
  `).join('');
}

async function loadTeachers() {
  const data = await api('/api/admin/teachers');
  if (!data) return;

  document.getElementById('teachersTable').innerHTML = (data.teachers || []).map(teacher => `
    <tr>
      <td>${teacher.nombre || 'Sin nombre'}</td>
      <td>${teacher.email || 'Sin correo'}</td>
      <td>${teacher.especialidad}</td>
      <td>${teacher.telefono || 'Sin teléfono'}</td>
      <td>${teacher.estado}</td>
    </tr>
  `).join('');

  const select = document.getElementById('courseTeacherSelect');
  select.innerHTML = '<option value="">Sin docente</option>' + (data.teachers || [])
    .filter(teacher => teacher.estado === 'activo')
    .map(teacher => `<option value="${teacher.id}">${teacher.nombre} - ${teacher.especialidad}</option>`)
    .join('');
}

async function loadCourses() {
  const data = await api('/api/admin/courses');
  if (!data) return;

  document.getElementById('coursesTable').innerHTML = (data.courses || []).map(course => `
    <tr>
      <td>${course.nombre}</td>
      <td>${course.grado}</td>
      <td>${course.docente}</td>
      <td>${course.estado}</td>
    </tr>
  `).join('');
}

async function loadAnnouncements() {
  const data = await api('/api/admin/announcements');
  if (!data) return;

  document.getElementById('announcementsList').innerHTML = (data.announcements || []).map(item => `
    <article class="card">
      <p class="muted">${item.fecha} · ${item.audiencia}</p>
      <h3>${item.titulo}</h3>
      <p>${item.contenido}</p>
      <button class="btn-danger" style="margin-top:12px;" onclick="deleteAnnouncement(${item.id})">Eliminar</button>
    </article>
  `).join('') || '<article class="card"><h3>Sin comunicados</h3><p>No hay comunicados publicados.</p></article>';
}

async function reloadAll() {
  await loadDashboard();
  await loadCharts();
  await loadStudents();
  await loadTeachers();
  await loadCourses();
  await loadAnnouncements();
}

window.deactivateStudent = async function(id) {
  if (!confirm('¿Deseas desactivar este estudiante?')) return;
  try {
    await api(`/api/admin/students/${id}`, { method: 'DELETE' });
    await reloadAll();
  } catch (error) {
    alert(error.message);
  }
};

window.deleteAnnouncement = async function(id) {
  if (!confirm('¿Deseas eliminar este comunicado?')) return;
  try {
    await api(`/api/admin/announcements/${id}`, { method: 'DELETE' });
    await reloadAll();
  } catch (error) {
    alert(error.message);
  }
};

document.getElementById('studentForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    await api('/api/admin/students', {
      method: 'POST',
      body: JSON.stringify(formToJson(event.target))
    });
    event.target.reset();
    await reloadAll();
    alert('Estudiante creado correctamente.');
  } catch (error) {
    alert(error.message);
  }
});

document.getElementById('teacherForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    await api('/api/admin/teachers', {
      method: 'POST',
      body: JSON.stringify(formToJson(event.target))
    });
    event.target.reset();
    await reloadAll();
    alert('Docente creado correctamente.');
  } catch (error) {
    alert(error.message);
  }
});

document.getElementById('courseForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    const payload = formToJson(event.target);
    if (!payload.docente_id) payload.docente_id = null;
    await api('/api/admin/courses', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
    event.target.reset();
    await reloadAll();
    alert('Curso creado correctamente.');
  } catch (error) {
    alert(error.message);
  }
});

document.getElementById('announcementForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  try {
    await api('/api/admin/announcements', {
      method: 'POST',
      body: JSON.stringify(formToJson(event.target))
    });
    event.target.reset();
    await reloadAll();
    alert('Comunicado publicado.');
  } catch (error) {
    alert(error.message);
  }
});

document.getElementById('generateDataBtn').addEventListener('click', async () => {
  try {
    const total = prompt('¿Cuántos estudiantes demo quieres generar?', '8') || '8';
    const grado = prompt('¿Para qué grado?', '10A') || '10A';
    const data = await api('/api/admin/generate-demo-data', {
      method: 'POST',
      body: JSON.stringify({ total: Number(total), grado })
    });
    await reloadAll();
    alert(data.message);
  } catch (error) {
    alert(error.message);
  }
});

document.getElementById('refreshChartsBtn').addEventListener('click', async () => {
  try {
    await loadCharts();
  } catch (error) {
    alert(error.message);
  }
});

document.getElementById('downloadStudentsReport').addEventListener('click', async () => {
  try {
    const response = await fetch('/api/admin/reports/students.csv', {
      headers: { Authorization: `Bearer ${token}` }
    });

    if (!response.ok) {
      const data = await response.json();
      throw new Error(data.message || 'No se pudo descargar el reporte.');
    }

    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'reporte_estudiantes.csv';
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
  } catch (error) {
    alert(error.message);
  }
});

window.addEventListener('resize', () => {
  clearTimeout(window.__chartsResizeTimer);
  window.__chartsResizeTimer = setTimeout(() => drawCharts(lastChartsData), 160);
});

reloadAll().catch((error) => {
  alert(`Error cargando panel: ${error.message}`);
});
