const express = require('express');
const path = require('path');
const cors = require('cors');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const app = express();
const PORT = Number(process.env.GATEWAY_PORT || 3000);

const AUTH_URL = `http://localhost:${process.env.AUTH_SERVICE_PORT || 4001}`;
const SCHOOL_URL = `http://localhost:${process.env.SCHOOL_SERVICE_PORT || 4002}`;
const ADMIN_URL = `http://localhost:${process.env.ADMIN_SERVICE_PORT || 4003}`;

app.use(cors());
app.use(express.static(path.join(__dirname, '..', 'public')));

function getBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on('data', chunk => chunks.push(chunk));
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}

function proxyTo(targetBase) {
  return async (req, res) => {
    try {
      const url = `${targetBase}${req.originalUrl}`;
      const headers = {};

      if (req.headers.authorization) headers.authorization = req.headers.authorization;
      if (req.headers['content-type']) headers['content-type'] = req.headers['content-type'];

      const options = {
        method: req.method,
        headers
      };

      if (!['GET', 'HEAD'].includes(req.method)) {
        const body = await getBody(req);
        if (body.length > 0) options.body = body;
      }

      const response = await fetch(url, options);
      const contentType = response.headers.get('content-type');
      const contentDisposition = response.headers.get('content-disposition');
      const buffer = Buffer.from(await response.arrayBuffer());

      res.status(response.status);
      if (contentType) res.setHeader('Content-Type', contentType);
      if (contentDisposition) res.setHeader('Content-Disposition', contentDisposition);
      return res.send(buffer);
    } catch (error) {
      console.error('Gateway proxy error:', error.message);
      return res.status(502).json({
        ok: false,
        message: 'No se pudo conectar con el microservicio. Verifica que todos los servicios estén activos con npm start.'
      });
    }
  };
}

app.use('/api/auth', proxyTo(AUTH_URL));
app.use('/api/public', proxyTo(SCHOOL_URL));
app.use('/api/school', proxyTo(SCHOOL_URL));
app.use('/api/admin', proxyTo(ADMIN_URL));

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`API Gateway y frontend listos en http://localhost:${PORT}`);
  console.log(`Auth: ${AUTH_URL} | School: ${SCHOOL_URL} | Admin: ${ADMIN_URL}`);
});
