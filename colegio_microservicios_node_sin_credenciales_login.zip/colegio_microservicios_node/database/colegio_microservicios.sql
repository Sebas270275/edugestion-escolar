-- Base de datos: colegio_microservicios
-- Proyecto: EduGestión Escolar con Node.js, microservicios y APIs
-- Importar en MySQL / phpMyAdmin

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP DATABASE IF EXISTS colegio_microservicios;
CREATE DATABASE colegio_microservicios CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE colegio_microservicios;

DROP TABLE IF EXISTS activity_logs;
DROP TABLE IF EXISTS announcements;
DROP TABLE IF EXISTS enrollments;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS teachers;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','estudiante','docente') NOT NULL DEFAULT 'estudiante',
  estado ENUM('activo','inactivo') NOT NULL DEFAULT 'activo',
  failed_login_attempts INT NOT NULL DEFAULT 0,
  locked_until DATETIME NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNIQUE,
  codigo VARCHAR(30) NOT NULL UNIQUE,
  documento VARCHAR(30) NOT NULL,
  grado VARCHAR(30) NOT NULL,
  acudiente VARCHAR(120) NOT NULL,
  telefono_acudiente VARCHAR(30),
  direccion VARCHAR(180),
  fecha_nacimiento DATE,
  estado ENUM('activo','inactivo') NOT NULL DEFAULT 'activo',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_students_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE teachers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT UNIQUE,
  especialidad VARCHAR(100) NOT NULL,
  telefono VARCHAR(30),
  estado ENUM('activo','inactivo') NOT NULL DEFAULT 'activo',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_teachers_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE courses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(120) NOT NULL,
  grado VARCHAR(30) NOT NULL,
  descripcion TEXT,
  docente_id INT NULL,
  estado ENUM('activo','inactivo') NOT NULL DEFAULT 'activo',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_courses_teacher FOREIGN KEY (docente_id) REFERENCES teachers(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE enrollments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  course_id INT NOT NULL,
  nota_actual DECIMAL(3,2) DEFAULT 0,
  estado ENUM('activo','retirado') NOT NULL DEFAULT 'activo',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_enrollment (student_id, course_id),
  CONSTRAINT fk_enrollments_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  CONSTRAINT fk_enrollments_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE announcements (
  id INT AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(160) NOT NULL,
  contenido TEXT NOT NULL,
  audiencia ENUM('todos','estudiantes','docentes','acudientes') NOT NULL DEFAULT 'todos',
  created_by INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_announcements_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE activity_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  accion VARCHAR(160) NOT NULL,
  detalle TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_logs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Usuarios de prueba.
-- Las contraseñas están encriptadas con bcrypt para que funcionen con el login de Node.js.
INSERT INTO users (id, nombre, email, password_hash, role, estado, failed_login_attempts, locked_until, created_at) VALUES
(1, 'Administrador Colegio', 'admin@colegio.edu.co', '$2a$10$HTQN1gemiAlmAB6cS/MdLebeeZ/7gELh1nFc6RgSwlytTuWurLoCy', 'admin', 'activo', 0, NULL, NOW()),
(2, 'María Docente', 'docente@colegio.edu.co', '$2a$10$eCp4fv0Jmb1lhlMh0fqEGeKFLQ/YkfIv8HyFYqAB/XGXuiBcXYVly', 'docente', 'activo', 0, NULL, NOW()),
(3, 'Juan Estudiante', 'estudiante@colegio.edu.co', '$2a$10$D3b4W1Bnc3iDpvESZVGY0e8Qrqjkytb.QPIy.1NtHAidAC2gh9nRC', 'estudiante', 'activo', 0, NULL, NOW());

INSERT INTO teachers (id, user_id, especialidad, telefono, estado, created_at) VALUES
(1, 2, 'Matemáticas', '3001234567', 'activo', NOW());

INSERT INTO students (id, user_id, codigo, documento, grado, acudiente, telefono_acudiente, direccion, fecha_nacimiento, estado, created_at) VALUES
(1, 3, 'EST-001', '1000000001', '10A', 'Ana Palacios', '3014567890', 'Barrio Centro', '2010-04-15', 'activo', NOW());

INSERT INTO courses (id, nombre, grado, descripcion, docente_id, estado, created_at) VALUES
(1, 'Matemáticas', '10A', 'Álgebra, funciones, derivadas básicas y resolución de problemas.', 1, 'activo', NOW()),
(2, 'Lengua Castellana', '10A', 'Comprensión lectora, producción textual y literatura.', 1, 'activo', NOW()),
(3, 'Ciencias Naturales', '10A', 'Biología, química básica y cuidado ambiental.', 1, 'activo', NOW()),
(4, 'Tecnología e Informática', '10A', 'Pensamiento computacional, ofimática y proyectos digitales.', 1, 'activo', NOW());

INSERT INTO enrollments (id, student_id, course_id, nota_actual, estado, created_at) VALUES
(1, 1, 1, 4.20, 'activo', NOW()),
(2, 1, 2, 4.00, 'activo', NOW()),
(3, 1, 3, 4.40, 'activo', NOW()),
(4, 1, 4, 4.60, 'activo', NOW());

INSERT INTO announcements (id, titulo, contenido, audiencia, created_by, created_at) VALUES
(1, 'Bienvenidos a EduGestión Escolar', 'EduGestión Escolar ya está disponible para estudiantes, docentes y administrativos.', 'todos', 1, NOW()),
(2, 'Reunión de acudientes', 'La reunión general será publicada en el calendario institucional.', 'acudientes', 1, NOW()),
(3, 'Entrega de actividades', 'Recuerden revisar sus cursos y mantenerse atentos a los comunicados.', 'estudiantes', 1, NOW());

INSERT INTO activity_logs (id, user_id, accion, detalle, created_at) VALUES
(1, 1, 'BASE DE DATOS IMPORTADA', 'Se importó la base de datos inicial del sistema escolar.', NOW()),
(2, 1, 'USUARIOS DE PRUEBA CREADOS', 'Se crearon usuarios admin, docente y estudiante para pruebas.', NOW()),
(3, 1, 'CURSOS DE PRUEBA CREADOS', 'Se crearon cursos, matrícula y comunicados iniciales.', NOW()),
(4, 1, 'SEGURIDAD DE LOGIN ACTIVADA', 'El sistema tiene bloqueo temporal de 1 minuto después de 3 intentos fallidos.', NOW());

ALTER TABLE users AUTO_INCREMENT = 4;
ALTER TABLE teachers AUTO_INCREMENT = 2;
ALTER TABLE students AUTO_INCREMENT = 2;
ALTER TABLE courses AUTO_INCREMENT = 5;
ALTER TABLE enrollments AUTO_INCREMENT = 5;
ALTER TABLE announcements AUTO_INCREMENT = 4;
ALTER TABLE activity_logs AUTO_INCREMENT = 5;

SET FOREIGN_KEY_CHECKS = 1;
