-- Actualización para agregar bloqueo temporal de login en una base ya importada.
-- Ejecutar en phpMyAdmin sobre la base de datos colegio_microservicios.

USE colegio_microservicios;

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS failed_login_attempts INT NOT NULL DEFAULT 0 AFTER estado;

ALTER TABLE users
  ADD COLUMN IF NOT EXISTS locked_until DATETIME NULL AFTER failed_login_attempts;

UPDATE users
SET failed_login_attempts = 0,
    locked_until = NULL;

INSERT INTO activity_logs (user_id, accion, detalle)
SELECT 1, 'SEGURIDAD DE LOGIN ACTUALIZADA', 'Se agregaron intentos fallidos y bloqueo temporal de 1 minuto después de 3 fallos.'
WHERE EXISTS (SELECT 1 FROM users WHERE id = 1);
