-- Versión compatible si tu MySQL no acepta ADD COLUMN IF NOT EXISTS.
-- Ejecuta solo las líneas ALTER que hagan falta según tu tabla users.

USE colegio_microservicios;

-- Si no existe la columna failed_login_attempts:
ALTER TABLE users ADD COLUMN failed_login_attempts INT NOT NULL DEFAULT 0 AFTER estado;

-- Si no existe la columna locked_until:
ALTER TABLE users ADD COLUMN locked_until DATETIME NULL AFTER failed_login_attempts;

UPDATE users
SET failed_login_attempts = 0,
    locked_until = NULL;
