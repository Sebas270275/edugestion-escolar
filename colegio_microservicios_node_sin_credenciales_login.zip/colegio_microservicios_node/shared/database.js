const mysql = require('mysql2/promise');
const bcrypt = require('bcryptjs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

let pool;
let setupPromise;

const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  multipleStatements: true
};

const dbName = process.env.DB_NAME || 'colegio_microservicios';

async function getServerConnection() {
  return mysql.createConnection(dbConfig);
}

async function createPool() {
  if (!pool) {
    pool = mysql.createPool({
      ...dbConfig,
      database: dbName,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      decimalNumbers: true
    });
  }
  return pool;
}

async function createTables(db) {
  await db.query(`
    CREATE TABLE IF NOT EXISTS users (
      id INT AUTO_INCREMENT PRIMARY KEY,
      nombre VARCHAR(120) NOT NULL,
      email VARCHAR(120) NOT NULL UNIQUE,
      password_hash VARCHAR(255) NOT NULL,
      role ENUM('admin','estudiante','docente') NOT NULL DEFAULT 'estudiante',
      estado ENUM('activo','inactivo') NOT NULL DEFAULT 'activo',
      failed_login_attempts INT NOT NULL DEFAULT 0,
      locked_until DATETIME NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS students (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT UNIQUE,
      codigo VARCHAR(30) NOT NULL UNIQUE,
      documento VARCHAR(30) NOT NULL,
      grado VARCHAR(30) NOT NULL,
      acudiente VARCHAR(120) NOT NULL,
      telefono_acudiente VARCHAR(30),
      direccion VARCHAR(180),
      fecha_nacimiento DATE,
      estado ENUM('activo','inactivo') NOT NULL DEFAULT 'activo',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT fk_students_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS teachers (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT UNIQUE,
      especialidad VARCHAR(100) NOT NULL,
      telefono VARCHAR(30),
      estado ENUM('activo','inactivo') NOT NULL DEFAULT 'activo',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT fk_teachers_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS courses (
      id INT AUTO_INCREMENT PRIMARY KEY,
      nombre VARCHAR(120) NOT NULL,
      grado VARCHAR(30) NOT NULL,
      descripcion TEXT,
      docente_id INT NULL,
      estado ENUM('activo','inactivo') NOT NULL DEFAULT 'activo',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT fk_courses_teacher FOREIGN KEY (docente_id) REFERENCES teachers(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS enrollments (
      id INT AUTO_INCREMENT PRIMARY KEY,
      student_id INT NOT NULL,
      course_id INT NOT NULL,
      nota_actual DECIMAL(3,2) DEFAULT 0,
      estado ENUM('activo','retirado') NOT NULL DEFAULT 'activo',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY unique_enrollment (student_id, course_id),
      CONSTRAINT fk_enrollments_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
      CONSTRAINT fk_enrollments_course FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS announcements (
      id INT AUTO_INCREMENT PRIMARY KEY,
      titulo VARCHAR(160) NOT NULL,
      contenido TEXT NOT NULL,
      audiencia ENUM('todos','estudiantes','docentes','acudientes') NOT NULL DEFAULT 'todos',
      created_by INT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT fk_announcements_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
    );

    CREATE TABLE IF NOT EXISTS activity_logs (
      id INT AUTO_INCREMENT PRIMARY KEY,
      user_id INT NULL,
      accion VARCHAR(160) NOT NULL,
      detalle TEXT,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      CONSTRAINT fk_logs_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    );
  `);
}


async function ensureAuthSecurityColumns(db) {
  const [failedAttemptsColumn] = await db.execute(
    "SHOW COLUMNS FROM users LIKE 'failed_login_attempts'"
  );
  if (failedAttemptsColumn.length === 0) {
    await db.execute('ALTER TABLE users ADD COLUMN failed_login_attempts INT NOT NULL DEFAULT 0 AFTER estado');
  }

  const [lockedUntilColumn] = await db.execute(
    "SHOW COLUMNS FROM users LIKE 'locked_until'"
  );
  if (lockedUntilColumn.length === 0) {
    await db.execute('ALTER TABLE users ADD COLUMN locked_until DATETIME NULL AFTER failed_login_attempts');
  }
}

async function findUserIdByEmail(db, email) {
  const [rows] = await db.execute('SELECT id FROM users WHERE email = ? LIMIT 1', [email]);
  return rows[0]?.id || null;
}

async function findTeacherIdByUserId(db, userId) {
  const [rows] = await db.execute('SELECT id FROM teachers WHERE user_id = ? LIMIT 1', [userId]);
  return rows[0]?.id || null;
}

async function findStudentIdByUserId(db, userId) {
  const [rows] = await db.execute('SELECT id FROM students WHERE user_id = ? LIMIT 1', [userId]);
  return rows[0]?.id || null;
}

async function insertUserIfMissing(db, { nombre, email, password, role }) {
  const passwordHash = await bcrypt.hash(password, 10);
  await db.execute(
    `INSERT INTO users (nombre, email, password_hash, role)
     VALUES (?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE nombre = VALUES(nombre), role = VALUES(role), estado = 'activo'`,
    [nombre, email, passwordHash, role]
  );
  return findUserIdByEmail(db, email);
}

async function seedBaseData(db) {
  const [userCountRows] = await db.execute('SELECT COUNT(*) AS total FROM users');
  const alreadyHadUsers = userCountRows[0].total > 0;

  const adminId = await insertUserIfMissing(db, {
    nombre: 'Administrador Colegio',
    email: 'admin@colegio.edu.co',
    password: 'Admin123*',
    role: 'admin'
  });

  const teacherUserId = await insertUserIfMissing(db, {
    nombre: 'María Docente',
    email: 'docente@colegio.edu.co',
    password: 'Docente123*',
    role: 'docente'
  });

  const studentUserId = await insertUserIfMissing(db, {
    nombre: 'Juan Estudiante',
    email: 'estudiante@colegio.edu.co',
    password: 'Estudiante123*',
    role: 'estudiante'
  });

  await db.execute(
    `INSERT INTO teachers (user_id, especialidad, telefono)
     VALUES (?, 'Matemáticas', '3001234567')
     ON DUPLICATE KEY UPDATE especialidad = VALUES(especialidad), telefono = VALUES(telefono), estado = 'activo'`,
    [teacherUserId]
  );

  await db.execute(
    `INSERT INTO students (user_id, codigo, documento, grado, acudiente, telefono_acudiente, direccion, fecha_nacimiento)
     VALUES (?, 'EST-001', '1000000001', '10A', 'Ana Palacios', '3014567890', 'Barrio Centro', '2010-04-15')
     ON DUPLICATE KEY UPDATE grado = VALUES(grado), acudiente = VALUES(acudiente), estado = 'activo'`,
    [studentUserId]
  );

  const teacherId = await findTeacherIdByUserId(db, teacherUserId);
  const studentId = await findStudentIdByUserId(db, studentUserId);

  const defaultCourses = [
    ['Matemáticas', '10A', 'Álgebra, funciones, derivadas básicas y resolución de problemas.'],
    ['Lengua Castellana', '10A', 'Comprensión lectora, producción textual y literatura.'],
    ['Ciencias Naturales', '10A', 'Biología, química básica y cuidado ambiental.'],
    ['Tecnología e Informática', '10A', 'Pensamiento computacional, ofimática y proyectos digitales.']
  ];

  for (const [nombre, grado, descripcion] of defaultCourses) {
    await db.execute(
      `INSERT INTO courses (nombre, grado, descripcion, docente_id)
       SELECT ?, ?, ?, ? FROM DUAL
       WHERE NOT EXISTS (SELECT 1 FROM courses WHERE nombre = ? AND grado = ?)`,
      [nombre, grado, descripcion, teacherId, nombre, grado]
    );
  }

  const [courses] = await db.execute('SELECT id FROM courses WHERE grado = ? LIMIT 4', ['10A']);
  for (const course of courses) {
    await db.execute(
      `INSERT IGNORE INTO enrollments (student_id, course_id, nota_actual)
       VALUES (?, ?, ?)`,
      [studentId, course.id, Number((3.8 + Math.random() * 1.1).toFixed(2))]
    );
  }

  const announcements = [
    ['Bienvenidos al Colegio Digital', 'La plataforma escolar ya está disponible para estudiantes, docentes y administrativos.', 'todos'],
    ['Reunión de acudientes', 'La reunión general será publicada en el calendario institucional.', 'acudientes'],
    ['Entrega de actividades', 'Recuerden revisar sus cursos y mantenerse atentos a los comunicados.', 'estudiantes']
  ];

  for (const [titulo, contenido, audiencia] of announcements) {
    await db.execute(
      `INSERT INTO announcements (titulo, contenido, audiencia, created_by)
       SELECT ?, ?, ?, ? FROM DUAL
       WHERE NOT EXISTS (SELECT 1 FROM announcements WHERE titulo = ?)`,
      [titulo, contenido, audiencia, adminId, titulo]
    );
  }

  if (!alreadyHadUsers) {
    await db.execute(
      'INSERT INTO activity_logs (user_id, accion, detalle) VALUES (?, ?, ?)',
      [adminId, 'BASE DE DATOS INICIALIZADA', 'Se crearon usuarios, cursos, matrícula y comunicados de prueba.']
    );
  }
}

async function setupDatabase() {
  if (setupPromise) return setupPromise;

  setupPromise = (async () => {
    const server = await getServerConnection();
    await server.query(`CREATE DATABASE IF NOT EXISTS \`${dbName}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`);
    await server.end();

    const db = await createPool();
    await createTables(db);
    await ensureAuthSecurityColumns(db);
    await seedBaseData(db);
    return db;
  })();

  return setupPromise;
}

async function getPool() {
  if (!pool) {
    await setupDatabase();
  }
  return pool;
}

async function logActivity(userId, accion, detalle = '') {
  const db = await getPool();
  await db.execute('INSERT INTO activity_logs (user_id, accion, detalle) VALUES (?, ?, ?)', [userId || null, accion, detalle]);
}

module.exports = {
  setupDatabase,
  getPool,
  logActivity
};
